def hachage(message):
    zero=""
    b = 256
    n = 251
    tab = 0
    for i in range(len(message)):
        tab += (ord(message[i]) * (b ** ((len(message) - i) - 1)))
    tab = tab % n
    bin=format(tab,"b")
    if(len(bin)<8):
        for i in range(8-len(bin)):
            zero+="0"
    bin=zero+bin
    return [bin,format(tab,'x')]

print("Entrer l'information ")
val=input()
print("infomation haché binaire :",hachage(val)[0],"\n","infomation haché hexadecimal :",hachage(val)[1])



